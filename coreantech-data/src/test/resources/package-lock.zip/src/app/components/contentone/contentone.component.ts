import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contentone',
  templateUrl: './contentone.component.html',
  styleUrls: ['./contentone.component.css']
})
export class ContentoneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
