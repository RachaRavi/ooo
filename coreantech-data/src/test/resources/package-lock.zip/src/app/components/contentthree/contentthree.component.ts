import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contentthree',
  templateUrl: './contentthree.component.html',
  styleUrls: ['./contentthree.component.css']
})
export class ContentthreeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
