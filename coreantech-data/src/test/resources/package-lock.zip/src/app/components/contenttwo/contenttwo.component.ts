import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contenttwo',
  templateUrl: './contenttwo.component.html',
  styleUrls: ['./contenttwo.component.css']
})
export class ContenttwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
