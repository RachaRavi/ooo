import { Component, OnInit, ViewChild } from '@angular/core';
import { AppService } from 'src/app/app.service';
import { User } from 'src/app/entities/user';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css']
})
export class LandingComponent implements OnInit {

  @ViewChild('closebutton',null) closebutton;

  newSignUp: boolean = false;
  isLoggedIn: boolean = false;
  showLoader: boolean = false;
  showLoginPopup: boolean = false;

  user: User = null;
  signupOTP: String = new String();

  constructor(public appService: AppService) { }

  ngOnInit() {
    this.user = new User();
  }


  /**
   * login
   */
  login() {
    this.newSignUp = false;
    this.showLoginPopup = true;
  }

  /**
   * Login/Signup submit
   */
  async submit() {

    //** ########## LOCAL ONLY TEST ############### ***/
    localStorage.setItem("session","test");
    this.appService.userSession = localStorage.getItem("session");
    this.closebutton.nativeElement.click();
    return;


    this.showLoader = true;
    console.log(this.user);
    if(this.newSignUp) {
      if(this.user.compare()) {
        alert("Password mismatch");
        this.showLoader = false;
        return;
      }
      await this.appService.signup(this.user).subscribe(data=>{
          console.log(data);
          if(!data.status) {
            alert("Invalid content please check");
          } else {
            this.user = JSON.parse(data.data);
            this.appService.userSession = this.user;
          }
          this.showLoader = false;
      });
      
    } else {
      await this.appService.login(this.user).subscribe(data=>{
          console.log(data);
          console.log(data.status);
          if(!data.status) {
            alert("Invalid username/password");
            this.showLoader = false;
          } else {
            this.user = JSON.parse(JSON.stringify(data.data));
            this.appService.userSession = this.user;
            console.log(this.user);
            this.showLoginPopup = false;
            this.closebutton.nativeElement.click();
            localStorage.setItem("session","test");
            this.appService.userSession = localStorage.getItem("session");
          }
          this.showLoader = false;
      });
    }
    //this.appService.validateUser(this.userName,this.password);
    this.isLoggedIn = true;
  }

  /**
   * signup
   */
  signup() {
    this.newSignUp = true;
  }
  

}
