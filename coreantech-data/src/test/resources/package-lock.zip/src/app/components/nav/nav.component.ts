import { Component, OnInit } from '@angular/core';
import { AppService } from 'src/app/app.service';
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  constructor(private router: Router,public appService: AppService) { }

  ngOnInit() {
  }

  logout() {
    localStorage.removeItem("session");
    this.appService.sessionOut();
  }

  gotoEmails() {
    this.router.navigate(['/emails']);
  }

}
