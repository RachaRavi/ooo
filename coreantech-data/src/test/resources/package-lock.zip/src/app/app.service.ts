import { Injectable } from '@angular/core';
import { Placeholder } from '@angular/compiler/src/i18n/i18n_ast';
import { PlaceholderSet, TablePlaceholder } from 'src/app/entities/placeholderSet';
import { TemplateInfo } from 'src/app/entities/templateInfo';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry , tap , map } from 'rxjs/operators';

const httpOptions = {
  headers: new HttpHeaders({ 
    'Access-Control-Allow-Origin':'*',
    'Content-Type':'application/json',
    'userid':'1'
  })
};

@Injectable({
  providedIn: 'root'
})

/**
 * Data interchange between pages.
 */
export class AppService {

  /**
   * STEP-1::
   * This property used in the Document-Flow: FirstStep, place holder set
   */
  public placeholderSet: PlaceholderSet = new PlaceholderSet();

  /**
   * STEP-2::
   * This property used in the Document-Flow: SecondStep, created template based on the first-step placeholders
   */
  public templateInfo: TemplateInfo = new TemplateInfo();

  /**
   * STEP-3:
   * This contains final data enteres by the User
   */
  public dataFinal: PlaceholderSet[];

  /**
   * Logged user session 
   */
  public userSession : any = null;

  constructor(private http: HttpClient) {
    console.log(":::::::: Check for user session::::::");
    this.sessionIn()
   }

  /**
   * Send email for guest user
   */
  async sendEmails(request: any) {
    httpOptions['responseType']='text';
    console.log(httpOptions);
    let res = await this.http.post("https://66d27xahg1.execute-api.ap-south-1.amazonaws.com/email",request,httpOptions).toPromise();
    console.log(res);
    //console.log(JSON.parse(res));
  }

  /**
   * Sign up New user
   * @param request
   */
  signup(request: any): Observable<any> {
    httpOptions['responseType']='json';
    console.log(httpOptions);
    let res = this.http.post("https://bn2f32xbff.execute-api.ap-south-1.amazonaws.com/signup",request,httpOptions).pipe(
      resp => {
        console.log(resp)
        return resp;
      }
    );
    return res;
    //console.log(JSON.parse(res));
  }

  /**
   * Login
   * @param request
   */
  login(request: any): Observable<any> {
    httpOptions['responseType']='json';
    console.log(httpOptions);
    let res = this.http.post("https://to6i870j1i.execute-api.ap-south-1.amazonaws.com/login",request,httpOptions).pipe(
      resp => {
        console.log(resp)
        return resp;
      }
    );
    return res;
    console.log(res);
    //console.log(JSON.parse(res));
  }

  /**
   * check validateUser
   */

   validateUser(username: any, password: any) {
    if(password.toUpperCase() == "12345"){
      this.userSession = {};
    }
   }

    

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong.
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // Return an observable with a user-facing error message.
    return throwError(
      'Something bad happened; please try again later.');
  }

  /**
   * session update
   */
  public sessionIn(): void{
    this.userSession = localStorage.getItem("session");
  }
  /**
   * session out
   */
  public sessionOut(): void{
    localStorage.removeItem("session");
    this.userSession = null;
  }
}
