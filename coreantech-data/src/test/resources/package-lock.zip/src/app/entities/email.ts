export class Email {
    id: any;
    name: any;
    email_id: any;
    template_name: any;
    asset_name: any;
    template_id: any;
    data: any;
    path: any;
    status: any;
    description: any;
    parent_id: any;
    created_date: any;
}


export class EmailCommunication{
    id: any;
    name: any;
    email_id: any;
    template_name: any;
    asset_name: any;
    template_id: any;
    data: any;
    path: any;
    status: any;
    description: any;
    parent_id: any;
    created_date: any;
    modified: any = [];

}