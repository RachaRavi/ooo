export class User {
    id: any;
    email: any;
    first_name: any;
    last_name: any;
    password: string;
    confirm_password: string;

    compare(): boolean {
        return !(this.password.valueOf() == this.confirm_password.valueOf());
    }
}