export class Dataset{
    id: any;
    name: any;
    dataList: any[]=[];
}

export class Customer {
    id: any;
    name: string;
    email: string;
    phone: any;
}


