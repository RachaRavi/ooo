export class Delivery{
    id: any;
    data: any[];
    templateHtml: any;
    name: string;
}

export class EmailDelivery extends Delivery {
    subject: any;
    toEmail: string;
    fromEmail: any='admin@coreantech.com';
}

export class Attachment {

}