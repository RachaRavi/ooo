import { Delivery, EmailDelivery } from 'src/app/entities/delivery';


export class Placeholder {

    id: any;
    name: string;
    type: string;
    description: string;
    data: any;
    styles: PlaceholderStyle[] = [];//[new PlaceholderStyle("CAPITAL","Capital",false),
                                  //new PlaceholderStyle("BOLD","Bold",false),
                                  //new PlaceholderStyle("UNDERLINE","Underline",false),
                                  //new PlaceholderStyle("ITALIC","Italic",false)];
}

/**
 * This is Asset class.
 */
export class PlaceholderSet {
    id: any;
    name: string;
    description: string;
    placeholders: Placeholder[]=[];

    delivery: EmailDelivery = new EmailDelivery();
}

export class TablePlaceholder extends Placeholder {
    columns: Placeholder[]=[];
    constructor(private placeholder: Placeholder){
    super();
    super.id = placeholder.id;
    super.name = placeholder.name;
    super.description = placeholder.description;
    super.type = placeholder.type;
    }
}

export class ListPlaceholder extends Placeholder {
    values: any[];
    constructor(private placeholder: Placeholder){
        super();
        super.id = placeholder.id;
        super.name = placeholder.name;
        super.description = placeholder.description;
        super.type = placeholder.type;
    }
}

export class PlaceholderStyle {
    name: string;
    display; string;
    isSelected: boolean;
    constructor(private styleName: string, private displayName: string, private selected : boolean) {
        this.name = styleName;
        this.isSelected = selected;
        this.display = displayName;
    }


}