import { PlaceholderSet } from 'src/app/entities/placeholderSet';

export class TemplateInfo {
    id: any;
    name: string;
    type: string;
    description: string;
    html: any="";
    asset: any;
    styles: any[];
    emailSubject: string = "Coreantech Welcome";
}

export class TemplateTypes {
    id: any;
    name: string;
    displayName: string;
}