import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomePageModule } from './pages/home-page/home-page.module';
import { HomePageComponent } from './pages/home-page/home-page.component';
import { CreatePageComponent } from './pages/create-page/create-page.component';
import { DocumentPageComponent } from './pages/document-page/document-page.component';
import { DocumentTemplatePageComponent } from './pages/document-template-page/document-template-page.component';
import { DocumentDataPageComponent } from './pages/document-data-page/document-data-page.component';
import { DocumentGeneratePageComponent } from './pages/document-generate-page/document-generate-page.component';
import { PlaceholderPageComponent } from './pages/placeholder-page/placeholder-page.component';
import { TemplatePageComponent } from './pages/template-page/template-page.component';
import { AssetPageComponent } from './pages/asset-page/asset-page.component';
import { DatasetPageComponent } from './pages/dataset-page/dataset-page.component'
import { EmailCommunicationPageComponent } from './pages/email-communication-page/email-communication-page.component';


const routes: Routes = [
  {path: '', component: HomePageComponent},
  {path: 'asset', component: AssetPageComponent},
  {path: 'template', component: TemplatePageComponent},
  {path: 'dataset', component: DatasetPageComponent},
  {path: 'template/create', component: CreatePageComponent},
  {path: 'document', component: DocumentPageComponent},
  {path: 'document/template', component: DocumentTemplatePageComponent},
  {path: 'document/data', component: DocumentDataPageComponent},
  {path: 'document/generate', component: DocumentGeneratePageComponent},
  {path: 'placeholder', component: PlaceholderPageComponent},
  {path: 'emails' , component: EmailCommunicationPageComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
