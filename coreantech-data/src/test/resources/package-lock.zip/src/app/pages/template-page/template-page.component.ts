import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router'
import { NgForm } from '@angular/forms';


import { TemplateInfo } from '../../entities/templateInfo'; 

@Component({
    selector: 'app-template-page',
    templateUrl: './template-page.component.html',
    styleUrls: ['./template-page.component.css']
})
/**
 * This for Template <TAB>
 */
export class TemplatePageComponent implements OnInit {

    teampltesList:TemplateInfo[]=[];

    constructor(private router: Router) {

    }
    ngOnInit() {
        this.dummyData();
    }

    /**
     * this will naviagte to step-2 i.e: create Template
     */
  next() {
       this.router.navigate(['/template/create'], { queryParams: { data: null } });
  }

    /***
     * ##############################################
     * ##################### TEST ###################
     * ##############################################
     * 
    */
    dummyData() {
        let customerTemplate = '{"id":"1","name":"CustomerTemplate","asset":"Customer","type":"Email","html":"<p>Customer&nbsp;<span class=\\"placeholder\\">{{Name}}</span></p><p>&nbsp;</p>"}';
        this.teampltesList.push(JSON.parse(customerTemplate));
        console.log(this.teampltesList);
    }
}
