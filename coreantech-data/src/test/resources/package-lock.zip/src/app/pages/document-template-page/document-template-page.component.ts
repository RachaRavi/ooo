import { Component, OnInit, Input } from '@angular/core';
import *  as DecoupledDocumentEditor from '../../../external-modules/ckeditor';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { PlaceholderService } from '../placeholder-page/placeholder.service';
import { AppService } from 'src/app/app.service';
import { Placeholder, PlaceholderSet, TablePlaceholder } from 'src/app/entities/placeholderSet';
import { TemplateInfo } from 'src/app/entities/templateInfo';


@Component({
  selector: 'app-document-template-page',
  templateUrl: './document-template-page.component.html',
  styleUrls: ['./document-template-page.component.css']
})

/**
 * This is for STEP-2::: document tempalte page
 */
export class DocumentTemplatePageComponent implements OnInit {

  public Editor = DecoupledDocumentEditor;
  public placeHolders: any;
  public templateInfo: TemplateInfo = new TemplateInfo();

  
  constructor(private router: Router, private activatedRoute: ActivatedRoute, private service: PlaceholderService, private appService: AppService) {
    console.log(" THIS IS FOR:::: DocumentTemplatePageComponent ::::");
    this.placeHolders = [];
    if(this.appService.placeholderSet != null)
      console.log(this.appService.placeholderSet.placeholders);
    for (let pHolder of this.appService.placeholderSet.placeholders) {
      if(pHolder.type.toUpperCase() == "TABLE" ) {
        for(let column of (pHolder as TablePlaceholder).columns) {
            this.placeHolders.push(pHolder.name + "[" + column.name + "]");
        }
      } else {
        this.placeHolders.push(pHolder.name);
      }
    }
    console.log('Placeholders::::' + this.placeHolders);

    DecoupledDocumentEditor.defaultConfig = {
      toolbar: [
        //'exportPdf',
        '|',
        'heading',
        '|',
        'placeholder',
        '|',
        'fontSize',
        'fontFamily',
        '|',
        'bold',
        'italic',
        'underline',
        'strikethrough',
        'highlight',
        '|',
        'alignment',
        '|',
        'numberedList',
        'bulletedList',
        '|',
        'indent',
        'outdent',
        '|',
        'todoList',
        'link',
        'blockQuote',
        'imageUpload',
        'insertTable',
        'mediaEmbed',
        '|',
        'undo',
        'redo',
        'pageBreak',
        'horizontalLine'
        
      ],

      // This value must be kept in sync with the language defined in webpack.config.js.
      language: 'en',
      placeholderProps: {
        types: this.placeHolders,
      }
    };

  }

  ngOnInit() {
    this.dummyData();
  }

  /**
   * 
   */
  public submit() {
    alert(this.templateInfo.html);
  }


  /**
   * previous page
   */
  prev() {
    this.router.navigate(['/document']);
  }

  /**
   * #### CKEDITOR related
   */
  public onReady(editor) {
    editor.ui.getEditableElement().parentElement.insertBefore(
      editor.ui.view.toolbar.element,
      editor.ui.getEditableElement()
    );
  }

  /**
   * Next page
   */
  next() {
    console.log("document template --> next()");
    this.appService.templateInfo = this.templateInfo;
    this.router.navigate(['/document/data'], { queryParams: { data: null } });
  }

  /**
   * Dummy Data
   */
  dummyData() {
    this.templateInfo.html = '<p>Customer&nbsp;</p><p>Name:&nbsp;<span class="placeholder">{{Name}}</span></p><p>City:&nbsp;<span class="placeholder">{{City}}</span></p><hr><p>Customer ordered below items:</p><figure class="table"><table><tbody><tr><td>Item Name</td><td>No. Of items</td><td>MRP Price</td></tr><tr><td><span class="placeholder">{{OrderedItems[Item Name]}}</span></td><td><span class="placeholder">{{OrderedItems[Quantity]}}</span></td><td><span class="placeholder">{{OrderedItems[MRP]}}</span></td></tr></tbody></table></figure><p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Total: &nbsp; &nbsp; &nbsp;&nbsp;<span class="placeholder">{{OrderedItems[Total]}}</span></p><p>&nbsp;</p><p>Thanks&amp;Regards,</p><p>Admin</p>';
  }

}