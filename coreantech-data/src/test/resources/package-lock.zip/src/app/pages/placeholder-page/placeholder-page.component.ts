import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router'
import { PlaceholderService } from './placeholder.service';
import { AppService } from 'src/app/app.service';
import { Placeholder, PlaceholderSet, TablePlaceholder } from 'src/app/entities/placeholderSet';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-placeholder-page',
  templateUrl: './placeholder-page.component.html',
  styleUrls: ['./placeholder-page.component.css']
})
export class PlaceholderPageComponent implements OnInit {

  asset: PlaceholderSet;
  id: String=null;
  placeholder: Placeholder = new Placeholder();

  placeholderSet: PlaceholderSet = new PlaceholderSet();
  //placeholderList: any[];

  @ViewChild('placeholderForm', null)
  placeholderForm: NgForm;
  isEdit: boolean = false;
  selectedItem: any;
  table: Placeholder = new Placeholder();
  isList: boolean = false;
  isTable: boolean = false;
  selectedColumn: any;
  isColumnEdit: boolean = false;

  constructor(private router: Router, private service: PlaceholderService, private appService: AppService) {
    console.log("::::This is for PlaceholderPageComponent:::");
  }

  ngOnInit() {
    if(this.id != null) {
      // EDIT
    } else {
      // NEW
      this.asset = new PlaceholderSet();
      this.dummyData();
      console.log(this.asset);
    }
  }

  save(){
    console.log(this.asset);
    console.log(JSON.stringify(this.asset));
    this.router.navigate(['/asset']);
  }

  back(){
    this.router.navigate(['/asset']);
  }

  addNew(){
    this.placeholder = new Placeholder();
  }

  addPlaceholder() {
    this.isEdit = false;
    this.placeholder = new Placeholder();
  }
  onSelect(item: any) {
    this.selectedItem = item;
    this.placeholder = this.selectedItem;
    console.log(this.selectedItem)
    if (item.type == 'table') {
      this.isList = true;
    } else {
      this.isList = false;
    }
  }
  onSelectColumn(item: any) {
    console.log(item);
    this.selectedColumn = item;
    this.table = this.selectedColumn;
  }

  deleteColumn(item: any) {
    this.selectedItem.columns.splice(this.selectedItem.columns.indexOf(this.selectedColumn, 1));
  }

  addColumn() {
    this.isColumnEdit = false;
    this.table = new Placeholder();

    console.log(this.selectedItem)

  }

  tableList(item: any) {
    if (item.columns) {
      if (this.isTable == false) {
        this.isTable = true
      } else {
        this.isTable = false
      }
    }
  }
  /**
   * 
   */
  delete() {
    // this.placeholderList.splice(this.placeholderList.indexOf(this.selectedItem), 1)
  }

  /**
   * Reste existing
   */
  reset() {
    this.placeholderForm.reset();
  }
  editPlaceholder() {
    this.isEdit = true;
  }

  columnEdit() {
    this.isColumnEdit = true;
  }

  /**
   * This for save into the list
   */
  savePlaceholder() {
    const item = { ...this.placeholder };
    for (let p of this.asset.placeholders) {
      if (p.name.toUpperCase() === item.name.toUpperCase()) {
        alert(' Placeholder already exists.');
        return;
      }
    }

    if (item.name != null && item.type != null) {
      if (item.type == 'table') {
        let table = new TablePlaceholder(item);
        this.asset.placeholders.push(table);
        //this.reset();
        return;
      }
      this.asset.placeholders.push(item);
      console.log(this.placeholder);
      this.reset();

    } else {
      alert('Please give name and Type');
    }
  }

  saveListPlaceholder() {
    this.selectedItem.columns.push(this.table);
    console.log(this.selectedItem);
    this.table = new Placeholder();
    // this.tableForm.reset(); 
    // const item = {...this.placeholder};
    // console.log(item);

  }


  dummyData(){
    let assetString = "{\"placeholders\":[{\"styles\":[],\"name\":\"Name\",\"type\":\"string\",\"description\":\"Customer Name\"},{\"styles\":[],\"name\":\"City\",\"type\":\"string\",\"description\":\"Customer city\"},{\"styles\":[],\"name\":\"Phone\",\"type\":\"string\",\"description\":\"Phone number\"},{\"styles\":[],\"placeholder\":{\"styles\":[],\"name\":\"Items\",\"type\":\"table\",\"description\":\"Ordered Items\"},\"columns\":[{\"styles\":[],\"name\":\"Item Name\",\"type\":\"string\",\"description\":\"item name\"},{\"styles\":[],\"name\":\"Item price\",\"type\":\"number\"},{\"styles\":[],\"name\":\"quantity\",\"type\":\"number\",\"description\":\"ordered quantity\"}],\"name\":\"Items\",\"description\":\"Ordered Items\",\"type\":\"table\"}],\"delivery\":{\"fromEmail\":\"admin@coreantech.com\"},\"name\":\"Customer\",\"description\":\"New Customer asset\"}";
    this.asset = JSON.parse(assetString);
  }

}
