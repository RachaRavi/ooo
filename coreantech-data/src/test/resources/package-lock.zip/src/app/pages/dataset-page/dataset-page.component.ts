import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router'
import { NgForm } from '@angular/forms';
import { TemplateInfo } from '../../entities/templateInfo';
import { Dataset, Customer } from 'src/app/entities/dataset';



@Component({
  selector: 'dataset-page',
  templateUrl: './dataset-page.component.html',
  styleUrls: ['./dataset-page.component.css']
})

/**
 * This is for dataset page
 */
export class DatasetPageComponent implements OnInit {


  /**
   * The below are the fields are populated from backend services:
   *  [datasets] 
   */
  datasets: any[]=[];

  addNewDataSet: boolean = false;
  newDatasetName: String = new String();

  newCustomerForDataset: any={};
  newCustomer: Customer = new Customer();

  constructor(private router: Router) {
        console.log("::::: THIS IS FOR DatasetPageComponent ::::::");
  }
  

  ngOnInit() {
    this.dummyData(); 
  }

  /**
   * Save:: Once save and route to the "template" page
   */
  next() {
    this.router.navigate(['/placeholder'], { queryParams: { data: null } });
  }

  enableAdd() {
      this.addNewDataSet = true;
  }

  disableAdd(){
    this.addNewDataSet = false;
  }

  saveNewDataset() {
      console.log(this.newDatasetName);
      let newDataset: Dataset = new Dataset();
      if(this.newDatasetName != ""){
        newDataset.name = this.newDatasetName;
        this.datasets.unshift(newDataset);
        this.newDatasetName = new String();
      } else {
          alert('Please enter the DataSet name.');
      }
  }

  addNewCustomer(item){
    console.log(item);
    this.newCustomerForDataset = item;
    this.newCustomer = new Customer();
  }
  
  saveNewCustomer() {
      console.log(this.newCustomer);
      this.newCustomerForDataset.dataList.unshift(this.newCustomer);
  }

  reset() {

  }

  /**
   * DUMMY BACKEND DATA
   */
  dummyData() {
    let dataset1: Dataset = new Dataset();
    let dataset2: Dataset = new Dataset();
    let dataset3: Dataset = new Dataset();

    dataset1.name="Customer-Group-One";
    dataset2.name="Customer-Group-Two";
    dataset3.name="Customer-Group-Three";

    let customer1: Customer =  new Customer();
    customer1.name="Test 1";
    customer1.email="test@test.com";
    customer1.phone="+91-1234567689"

    let customer2: Customer =  new Customer();
    customer2.name="Test 1";
    customer2.email="test@test.com";
    customer2.phone="+91-1234567689"

    dataset1.dataList.push(customer1);
    dataset1.dataList.push(customer2);

    dataset2.dataList.push(customer1);
    dataset2.dataList.push(customer2);

    dataset3.dataList.push(customer1);
    dataset3.dataList.push(customer2);

    this.datasets.push(dataset1);
    this.datasets.push(dataset2);
    this.datasets.push(dataset3);
   
  }
}
