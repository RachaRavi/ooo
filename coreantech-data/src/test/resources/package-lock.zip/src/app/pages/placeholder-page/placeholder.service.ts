import { Injectable } from '@angular/core';
import { Placeholder, PlaceholderSet, TablePlaceholder } from 'src/app/entities/placeholderSet';

@Injectable({
  providedIn: 'root'
})
export class PlaceholderService {
  placeholderItems: Placeholder[] = [];
  constructor() { 
    this.dummyData();
  }
  setPlaceholders(item: any) {
    this.placeholderItems.push(item)
  }
  getPlaceholders() {
    return this.placeholderItems;
  }

  savePlaceholders(item: any) {
    if (localStorage.getItem('placeholders')) {
      this.placeholderItems = JSON.parse(localStorage.getItem('placeholders'));
    }
    this.placeholderItems.push(item);
    localStorage.setItem('products', JSON.stringify(this.placeholderItems));
  }


  dummyData() {
    let placeholdersTest = '[{  "id": "1",  "name": "Name",  "type": "Text",  "description": "customer name"},{  "id": "2,",  "name": "City",  "type": "Text",  "description": "city"},{  "id": "3",  "name": "OrderedItems",  "type": "Table",  "description": "Customer ordered items",  "columns": [{  "id": "1",  "name": "Item Name",  "type": "Text",  "description": "Item Name"},{  "id": "2",  "name": "Quantity",  "type": "Number",  "description": "Number of units"},{  "id": "3",  "name": "MRP",  "type": "Number",  "description": "MRP Price for each item"},{  "id": "4",  "name": "Total",  "type": "Number",  "description": "Total"}  ]}  ]';
    this.placeholderItems = JSON.parse(placeholdersTest);
  }

}
