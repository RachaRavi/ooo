import { Component, OnInit, Input } from '@angular/core';
import *  as DecoupledDocumentEditor from '../../../external-modules/ckeditor';
import { Router, ActivatedRoute, Params } from '@angular/router';
import * as  Mustache from 'mustache';
import 'xmldom';
import { AppService } from 'src/app/app.service';

@Component({
    selector: 'app-document-generate-page',
    templateUrl: './document-generate-page.component.html',
    styleUrls: ['./document-generate-page.component.css']
})

export class DocumentGeneratePageComponent implements OnInit {

    public Editor = DecoupledDocumentEditor;
    templateHtml: any;
    placeholderValues: any[];

    finalDocs: string[] = [];
    finalHtml: string;

    public model = {
        content: '<p>Loading..</p>',
    };

    constructor(private router: Router, private activatedRoute: ActivatedRoute, private appService: AppService) {

        console.log("::::: THIS IS FOR::::DocumentGeneratePageComponent");
        console.log(this.appService.templateInfo);
        console.log(this.appService.dataFinal);

        this.placeholderValues = this.appService.dataFinal;
        if(this.appService.templateInfo != null)
            this.templateHtml = this.appService.templateInfo.html;

        var html = "";
        var templateHtmlFinal = null;
        this.placeholderValues.forEach((value, index) => {
            console.log(value.placeholders);
            var props = new Object();

            // This loop will constructs the input object for the Mustache template
            // This logic should be externalize
            for(var place of value.placeholders) {
                console.log(place);
                var key = place.name;
                var value = null;
                if(place.type.toUpperCase() === "TABLE") {
                    value = [];
                    //DATA[]
                    for(var r of place.data) {
                        //COLUMNS[]
                        var row = new Object();
                        for(var rr of r) {
                            var rkey = place.name +"["+ rr.name+"]";
                            var rdata = rr.data;
                            row[rkey] = rdata;
                        }
                        value.push(row);
                    }
                } else {
                    value = place.data;
                }
                props[key] = value;    
            }
            console.log(props);
            let parser = new DOMParser();
            let parsedHtml = parser.parseFromString(this.templateHtml, 'text/html');
            console.log(parsedHtml);
            

            //Customize the template if it contains any Tanles
            // This logic need to be exetrnalize or Need to use some DOM Parser
            if(templateHtmlFinal == null) {
                var replaces = [];
                this.templateHtml.match(/<table>(.*)<\/table>/g).forEach(d=>{
                    var collectionName = d.match(/({{)([^[]*)/g)[0].replace("{{","");
                    let input = d.split("</tr>");
                    console.log(input);
                    let output = input[0].replace(/td>/g,"th>").replace().replace(/<tbody>/g,"<thead>") + "</tr></thead>{{#"+collectionName+"}}<tbody>";
                    console.log(input);
                    console.log(output);
                    console.log(collectionName);
                    var replacesNeeded = { source: input[0] , target: output};

                    let output1 = input[1] +"</tr>{{/"+collectionName+"}}";
                    var replacesNeeded1 = { source: input[1] , target: output1};

                    replaces.push(replacesNeeded);
                    replaces.push(replacesNeeded1);
                });

                replaces.forEach( r=>{
                    console.log(r);
                    this.templateHtml = this.templateHtml.replace(r.source,r.target);
                });
            }
            templateHtmlFinal = this.templateHtml;
            console.log(this.templateHtml);
            var out = Mustache.render(templateHtmlFinal.replace(/placeholder/g, "placeholder1"), props);
            if (index == 0) html = out;
            else html = html + ' <div class="page-break" style="page-break-after:always;"><span style="display:none;">&nbsp;</span></div><p>&nbsp;</p><p>&nbsp;</p> ' + out;
        });

        this.finalHtml = html;

        this.buildCkeditor();

    }

    submit() {
        Mustache.render();
    }


    prev() {
        this.router.navigate(['/document/data'],{ queryParams: { preview: true } });
    }


    /**
     * This is Overrided method for OnInit
     */
    ngOnInit() {
    }

    buildCkeditor() {
        DecoupledDocumentEditor.defaultConfig = {
            toolbar: [
                'exportPdf',
                '|',
                'heading',
                '|',
                'fontSize',
                'fontFamily',
                '|',
                'bold',
                'italic',
                'underline',
                'strikethrough',
                'highlight',
                '|',
                'alignment',
                '|',
                'numberedList',
                'bulletedList',
                '|',
                'indent',
                'outdent',
                '|',
                'todoList',
                'link',
                'blockQuote',
                'imageUpload',
                'insertTable',
                'mediaEmbed',
                '|',
                'undo',
                'redo',
                'pageBreak',
                '|'
            ],

            // This value must be kept in sync with the language defined in webpack.config.js.
            language: 'en'
        };

    }

    public onReady(editor) {
        editor.ui.getEditableElement().parentElement.insertBefore(
            editor.ui.view.toolbar.element,
            editor.ui.getEditableElement()
        );
    }
}