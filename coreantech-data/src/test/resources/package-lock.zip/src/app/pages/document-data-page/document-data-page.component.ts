import { Component, OnInit, Input, ViewChild } from '@angular/core';
import *  as DecoupledDocumentEditor from '../../../external-modules/ckeditor';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { NgForm } from '@angular/forms';
import { PlaceholderSet, TablePlaceholder } from 'src/app/entities/placeholderSet';
import { Placeholder } from 'src/app/entities/placeholderSet';
import { EmailDelivery } from 'src/app/entities/delivery';



@Component({
    selector: 'app-document-data-page',
    templateUrl: './document-data-page.component.html',
    styleUrls: ['./document-data-page.component.css']
})

/**
 * 
 */
export class DocumentDataPageComponent implements OnInit {

    isVisible: boolean;
    @ViewChild('placeholderForm', null)
    placeholderForm: NgForm;
    selectedItem: any;
    dataList: any[] = [];
    placeholderSet: PlaceholderSet = new PlaceholderSet();
    column: any[] = [];
    isEmail = false

    // OTP MODEL REALTED 3 PROPERTIES
    otpEmail:any;
    otpPhone:any;
    otp:any;
    constructor(private router: Router, private activatedRoute: ActivatedRoute, private appService: AppService) {
        console.log(":: THIS IS FOR::: DocumentDataPageComponent :::");
        if(this.appService.dataFinal != null) {
            this.dataList = this.appService.dataFinal;
        }
        if(this.appService.placeholderSet != null)
         console.log(this.appService.placeholderSet.placeholders);
        // this.placeholderList = this.appService.placeholderSet.placeholders
    }

    public submit() {
        console.log('---- submit-generate ---');
        this.appService.dataFinal = this.dataList;
        this.router.navigate(['/document/generate'], { queryParams: { data: null } });
    }


    prev() {
        this.router.navigate(['/document/template']);
    }


    add() {
        let data = JSON.stringify(this.appService.placeholderSet);
        console.log(data);
        this.placeholderSet = JSON.parse(data);
        console.log(this.placeholderSet);
        this.addItem(null);

        // Check what kind of delivery from Template or etc
        if("EMAIL" == 'EMAIL') {
            let emailDelivery: EmailDelivery  = new EmailDelivery();
            this.placeholderSet.delivery = emailDelivery;
        }
        
    }

    addItem(item: any){
        let data: any = [];
        if(item == null){
             data = this.placeholderSet;
             for(let item of data.placeholders){
                console.log(item)
                console.log(item.type == 'Table')
                if((item.type.toUpperCase() == "TABLE" || item.type.toUpperCase() == "LIST" ) && item.columns != null){
                    if(item.data == null)
                       item.data = [];
                       let clns = JSON.parse(JSON.stringify(item.columns));
                       item.data.push(clns);
    
                }
                console.log(item.data);
            }
        }else{
            let clns = JSON.parse(JSON.stringify(item.columns));
            item.data.push(clns);
            console.log(item)
        }
        console.log(data);
       

     }

     deleteItem(item: any,index: any) {
        console.log(item);
        console.log(index);
        item.data.splice(index,1);
     }

   
    /**
     * This is Overrided method for OnInit
     */
    ngOnInit() {
    }
    saveData() {

        console.log(this.placeholderSet);
        this.dataList.push(this.placeholderSet);
        console.log(this.dataList)

    }



    
    reset() {
        this.placeholderForm.reset();
    }
    /**
     * 
     */
    onSelect(item: any) {
        this.selectedItem = item;
        console.log(this.selectedItem);

        // this.placeholder = item;
    }

    edit() {
        this.placeholderSet = this.selectedItem;
        console.log(this.placeholderSet)
    }

    /**
     * 
     */
    delete() {
        this.dataList.splice(this.dataList.indexOf(this.selectedItem), 1)
    }

    /**
     * 
     */
    emailSentSuccessMessage: boolean = false;
    showLoader: boolean = false;
    showEmailButton: boolean = true;
    sendEmail(){
        this.emailSentSuccessMessage=false;
    }

    /**
     * Valiadte the OTP and send emails
     *   // STEP-1::: User entered OTP need to be validated
     *   // STPE-2::: Validate the Template content & Data content
     *   // Mainly, focus on if the content found illegal words or any suspecting words
     */
    async validateAndSendEmails() {

        //STEP-1: validate otp
        if(this.otp != '12345') return;


        this.showLoader = true;
        this.showEmailButton = false;
        let serviceRequet = this.getDataForServiceCall();
        console.log(serviceRequet);
        
        if(serviceRequet.data.length == 0) {
            this.showLoader = false;
            this.showEmailButton = true;
            alert("Input data is empty. Please add the Data.");
            return;
        }    
        

        await this.appService.sendEmails(serviceRequet).then(
            (data) => {
                console.log(data);
                this.emailSentSuccessMessage=true;
                this.showLoader = false;
                this.showEmailButton = true;
            }),(
            (error) => {
                console.log(error);
                console.log("::: WRONG::::");
                this.showEmailButton = true;
            }

        );

        // The below is the final boolean for sucess message
        
    }

    getDataForServiceCall(): any {

        console.log("::::: Start the service call process data :::::");
        console.log(this.appService.templateInfo);
        
        let request = new Object();

        let placeholderValues = this.dataList;
        let templateHtml = this.appService.templateInfo.html;

        var html = "";
        var templateHtmlFinal = null;

        // FIRST::: Create template information
        //Customize the template if it contains any Tanles
        // This logic need to be exetrnalize or Need to use some DOM Parser
        if(templateHtmlFinal == null) {
            var replaces = [];
            templateHtml.match(/<table>(.*)<\/table>/g).forEach(d=>{
                var collectionName = d.match(/({{)([^[]*)/g)[0].replace("{{","");
                let input = d.split("</tr>");
                console.log(input);
                let output = input[0].replace(/td>/g,"th>").replace().replace(/<tbody>/g,"<thead>") + "</tr></thead>{{#"+collectionName+"}}<tbody>";
                console.log(input);
                console.log(output);
                console.log(collectionName);
                var replacesNeeded = { source: input[0] , target: output};

                let output1 = input[1] +"</tr>{{/"+collectionName+"}}";
                var replacesNeeded1 = { source: input[1] , target: output1};

                replaces.push(replacesNeeded);
                replaces.push(replacesNeeded1);
            });

            replaces.forEach( r=>{
                console.log(r);
                templateHtml = templateHtml.replace(r.source,r.target);
            });
        }
        request['template'] = templateHtml;

        console.log(request);

        let requestData = [];
        placeholderValues.forEach((value, index) => {
            console.log(value);
            console.log(value.delivery);
            var props = new Object();
            props['delivery'] = value.delivery; 
            props['delivery'].subject = this.appService.templateInfo.emailSubject;
            // This loop will constructs the input object for the Mustache template
            // This logic should be externalize
            for(var place of value.placeholders) {
                console.log(place);
                var key = place.name;
                var value = null;
                if(place.type.toUpperCase() === "TABLE") {
                    value = [];
                    //DATA[]
                    for(var r of place.data) {
                        //COLUMNS[]
                        var row = new Object();
                        for(var rr of r) {
                            var rkey = place.name +"["+ rr.name+"]";
                            var rdata = rr.data;
                            row[rkey] = rdata;
                        }
                        value.push(row);
                    }
                } else {
                    value = place.data;
                }
                props[key] = value;    
            }
            console.log(props);
            requestData.push(props);
        });

        request['data'] = requestData;
        console.log(request);
        return request;
    }

}