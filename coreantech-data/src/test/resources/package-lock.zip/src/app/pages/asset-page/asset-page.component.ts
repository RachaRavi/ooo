import { Component, OnInit, ViewChild , ElementRef} from '@angular/core';
import { Router } from '@angular/router'
import { NgForm } from '@angular/forms';
import { TemplateInfo } from '../../entities/templateInfo';
import *  as DecoupledDocumentEditor from '../../../external-modules/ckeditor';
declare const gapi: any;


@Component({
  selector: 'app-asset-page',
  templateUrl: './asset-page.component.html',
  styleUrls: ['./asset-page.component.css']
})

/**
 * This is for Asset page
 */
export class AssetPageComponent implements OnInit {


  /**
   * The below are the fields are populated from backend services:
   *  [assets] 
   */
  assetList: any[]=[];

  constructor(private router: Router,private element: ElementRef) {
        console.log("::::: THIS IS FOR AssetPageComponent ::::::");
  }
  

  ngOnInit() {
    this.dummyData(); 
  }

  /**
   * Save:: Once save and route to the "template" page
   */
  next() {
    this.router.navigate(['/placeholder'], { queryParams: { data: null } });
  }

  

  /**
   * DUMMY BACKEND DATA
   */
  dummyData() {
    this.assetList = [{ "id": "1", "name": "CustomerMonthlyInvoice", "description": "Customer Monthly Invoice Bill"},
                  { "id": "2", "name": "CustomerOrderedInvoice", "description": "Customer Ordered Invoice"},
                  { "id": "3", "name": "StudentsExamResult", "description": "Students Exam Result"   } ,
                  { "id": "4", "name": "WelcomeEmail", "description": "Send welcome email for New customer"   } ];
  }


  private clientId:string = '409167539692-4eqnaq2jd1itl211gsgh3m2k7i02aefa.apps.googleusercontent.com';
  
  private scope = [
    'profile',
    'email',
    'https://www.googleapis.com/auth/plus.me',
    'https://www.googleapis.com/auth/contacts.readonly',
    'https://www.googleapis.com/auth/admin.directory.user.readonly',
    'https://www.googleapis.com/auth/gmail.send'
  ].join(' ');

  public auth2: any;
  public googleInit() {
    let that = this;
    gapi.load('auth2', function () {
      that.auth2 = gapi.auth2.init({
        client_id: that.clientId,
        cookiepolicy: 'single_host_origin',
        scope: that.scope
      });
      that.attachSignin(that.element.nativeElement.firstChild);
    });
  }
  public attachSignin(element) {
    let that = this;
    this.auth2.attachClickHandler(element, {},
      function (googleUser) {

        let profile = googleUser.getBasicProfile();
        console.log('Token || ' + googleUser.getAuthResponse().id_token);
        console.log('ID: ' + profile.getId());
        console.log('Name: ' + profile.getName());
        console.log('Image URL: ' + profile.getImageUrl());
        console.log('Email: ' + profile.getEmail());
        //YOUR CODE HERE


      }, function (error) {
        console.log(JSON.stringify(error, undefined, 2));
      });
  }
  ngAfterViewInit() {
    this.googleInit();
  }
}
