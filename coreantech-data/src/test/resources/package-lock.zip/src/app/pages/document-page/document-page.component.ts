import { Component, OnInit, ViewChild } from '@angular/core';
import *  as DecoupledDocumentEditor from '../../../external-modules/ckeditor';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { Placeholder, PlaceholderSet, TablePlaceholder } from 'src/app/entities/placeholderSet';
import { NgForm } from '@angular/forms';
import { PlaceholderService } from 'src/app/pages/placeholder-page/placeholder.service';


@Component({
  selector: 'app-document-page',
  templateUrl: './document-page.component.html',
  styleUrls: ['./document-page.component.css']
})

/**
 * Document Step-1 flow:
 */
export class DocumentPageComponent implements OnInit {


  placeholderSet: PlaceholderSet = new PlaceholderSet();
  placeholder: Placeholder = new Placeholder();
  placeholderList: any[];

  @ViewChild('placeholderForm', null)
  placeholderForm: NgForm;
  isEdit: boolean = false;
  selectedItem: any;
  table: Placeholder = new Placeholder();
  isList: boolean = false;
  isTable: boolean = false;
  selectedColumn: any;
  isColumnEdit: boolean = false;

  constructor(private router: Router, private service: PlaceholderService, private appService: AppService) {
    console.log("::::This is for DocumentPageComponent:::");
    this.placeholderList = this.placeholderSet.placeholders;
    this.getPlaceholder();
  }

  ngOnInit() {
    // this.dummyData();
  }

  add() {
    this.router.navigate(['/document']);
  }

  getPlaceholder() {
    this.placeholderList = this.service.getPlaceholders();
  }

  addPlaceholder() {
    this.isEdit = false;
    this.placeholder = new Placeholder();
  }
  onSelect(item: any) {
    this.selectedItem = item;
    this.placeholder = this.selectedItem;
    console.log(this.selectedItem)
    if (item.type == 'table') {
      this.isList = true;
    } else {
      this.isList = false;
    }
    console.log(this.placeholderList)
  }
  onSelectColumn(item: any) {
    console.log(item);
    this.selectedColumn = item;
    this.table = this.selectedColumn;
  }

  deleteColumn(item: any) {
    this.selectedItem.columns.splice(this.selectedItem.columns.indexOf(this.selectedColumn, 1));
  }

  addColumn() {
    this.isColumnEdit = false;
    this.table = new Placeholder();

    console.log(this.selectedItem)

  }

  tableList(item: any) {
    if (item.columns) {
      if (this.isTable == false) {
        this.isTable = true
      } else {
        this.isTable = false
      }
    }
  }
  /**
   * 
   */
  delete() {
    this.placeholderList.splice(this.placeholderList.indexOf(this.selectedItem), 1)
  }

  /**
   * Reste existing
   */
  reset() {
    this.placeholderForm.reset();
  }
  editPlaceholder() {
    this.isEdit = true;
  }

  columnEdit() {
    this.isColumnEdit = true;
  }

  /**
   * This for save into the list
   */
  savePlaceholder() {
    const item = { ...this.placeholder };
    for (let p of this.service.getPlaceholders()) {
      if (p.name.toUpperCase() === item.name.toUpperCase()) {
        alert(' Placeholder already exists.');
        return;
      }
    }

    if (item.name != null && item.type != null) {
      if (item.type == 'table') {
        let table = new TablePlaceholder(item);
        this.service.setPlaceholders(table);
        this.reset();
        return;
      } else if (item.type == 'list') {
        let table = new TablePlaceholder(item);
        let singleColumn:Placeholder  = new Placeholder();
        singleColumn.id = item.id;
        singleColumn.name = item.name;
        singleColumn.type = item.type;
        singleColumn.description = item.description;
        singleColumn.styles = item.styles;
        singleColumn.data = item.data;
        table.columns.push(singleColumn);
        this.service.setPlaceholders(table);
        this.reset();
        return;
      }
      this.service.setPlaceholders(item);
      console.log(this.placeholder);
      this.reset();

    } else {
      alert('Please give name and Type');
    }
  }

  saveListPlaceholder() {
    this.selectedItem.columns.push(this.table);
    console.log(this.selectedItem);
    this.table = new Placeholder();
    // this.tableForm.reset(); 
    console.log(this.placeholderList);
    // const item = {...this.placeholder};
    // console.log(item);




  }

  /**
   * this will naviagte to step-2 i.e: create Template
   */
  next() {
    this.placeholderSet.placeholders = this.service.getPlaceholders();
    this.appService.placeholderSet = this.placeholderSet;
    this.router.navigate(['/document/template'], { queryParams: { data: null } });
  }

  dummyData() {
    this.placeholderList = [{  "id": "1",  "name": "Name",  "type": "Text",  "description": "customer name"},{  "id": "2,",  "name": "City",  "type": "Text",  "description": "city"},{  "id": "3",  "name": "OrderedItems",  "type": "Table",  "description": "Customer ordered items",  "columns": [{  "id": "1",  "name": "Item Name",  "type": "Text",  "description": "Item Name"},{  "id": "2",  "name": "Quantity",  "type": "Number",  "description": "Number of units"},{  "id": "3",  "name": "MRP",  "type": "Number",  "description": "MRP Price for each item"},{  "id": "4",  "name": "Total",  "type": "Number",  "description": "Total"}  ]}  ];
  }
}
