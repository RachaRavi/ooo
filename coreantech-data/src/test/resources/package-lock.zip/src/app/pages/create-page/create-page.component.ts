import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router'
import { NgForm } from '@angular/forms';
import { TemplateInfo } from '../../entities/templateInfo';
import *  as DecoupledDocumentEditor from '../../../external-modules/ckeditor';



@Component({
  selector: 'app-create-page',
  templateUrl: './create-page.component.html',
  styleUrls: ['./create-page.component.css']
})

/**
 * This is Template create 
 * Rule-1: If Template Type as "Email" Then, No Styles / disable
 * Rule-2: If Template type as Email & Template, then UI should show-up 2 ckeditors 1 for EMAIL message & 2 for Attachment/document
 * Rule-3: If Template type as "Message", then UI should limit the number of character's in ckeditor
 */
export class CreatePageComponent implements OnInit {


  /**
   * The below are the fields are populated from backend services:
   *  [assets , types] 
   */
  assets: string[]=[];
  types: any[]=[];
  styles: any[]=[];

  public Editor = DecoupledDocumentEditor;
  public template: TemplateInfo;

  constructor(private router: Router) {
    this.template = new TemplateInfo();
    DecoupledDocumentEditor.defaultConfig = {
      toolbar: [
        'exportPdf',
        '|',
        'heading',
        '|',
        'fontSize',
        'fontFamily',
        '|',
        'bold',
        'italic',
        'underline',
        'strikethrough',
        'highlight',
        '|',
        'alignment',
        '|',
        'numberedList',
        'bulletedList',
        '|',
        'indent',
        'outdent',
        '|',
        'todoList',
        'link',
        'blockQuote',
        'imageUpload',
        'insertTable',
        'mediaEmbed',
        '|',
        'undo',
        'redo',
        'pageBreak',
        'horizontalLine',
        '|',
        'placeholder'
      ],

      // This value must be kept in sync with the language defined in webpack.config.js.
      language: 'en',
      placeholderProps: {
        types: [],
      }

    };

  }

  ngOnInit() {
  }

  public submit() {
    console.log('---- submit ---');
    alert(this.template.html);
  }

  /**
   * Save:: Once save and route to the "template" page
   */
  save() {
    this.router.navigate(['/template'], { queryParams: { data: null } });
  }

  public onReady(editor) {
    editor.ui.getEditableElement().parentElement.insertBefore(
      editor.ui.view.toolbar.element,
      editor.ui.getEditableElement()
    );
  }


  /**
   * DUMMY BACKEND DATA
   */
  dummyData() {
    this.assets = ["Customer","Student","Worker","Employee-1","Worker-1"];
    this.types = [{name: "EMAIL",displayName:"Email"},
                  {name: "ATTACHMENT",displayName:"Attachment/Document"},
                  {name: "EMAIL_ATTACHMENT",displayName:"Email & Attachment"},
                  {name: "MESSAGE",displayName:"Message"},
                  {name: "DOCUMENT",displayName:"Document"}];
    this.styles = [{name: "BORDER" , displayName: "Border Line" , selected: false},
                   {name: "DOT_BORDER" , displayName: "Dotted border Line" , selected: false}];
  }
}
