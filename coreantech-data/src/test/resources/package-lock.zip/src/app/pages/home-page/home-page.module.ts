import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HomePageComponent } from './home-page.component';
import { BannerComponent } from 'src/app/components/banner/banner.component';
import { EndComponent } from 'src/app/components/end/end.component';
import { CreatePageComponent } from '../create-page/create-page.component';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { ContentComponent } from 'src/app/components/content/content.component';
import { ContentoneComponent } from 'src/app/components/contentone/contentone.component';
import { ContenttwoComponent } from 'src/app/components/contenttwo/contenttwo.component';
import { ContentthreeComponent } from 'src/app/components/contentthree/contentthree.component';
import { DocumentPageComponent } from '../document-page/document-page.component';
import { DocumentTemplatePageComponent } from '../document-template-page/document-template-page.component';
import { DocumentDataPageComponent } from '../document-data-page/document-data-page.component';
import { DocumentGeneratePageComponent } from '../document-generate-page/document-generate-page.component';
import { ViewPageComponent } from '../view-page/view-page.component';
import { TemplatePageComponent } from '../template-page/template-page.component';
import { AssetPageComponent } from '../asset-page/asset-page.component';
import { DatasetPageComponent } from '../dataset-page/dataset-page.component';

import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { PlaceholderPageComponent } from '../placeholder-page/placeholder-page.component';
import { PlaceholderService } from '../placeholder-page/placeholder.service';

import { LandingComponent } from 'src/app/components/landing/landing.component';
import { EmailCommunicationPageComponent } from '../email-communication-page/email-communication-page.component';



@NgModule({
  declarations: [HomePageComponent, ContentComponent, BannerComponent, ContentoneComponent, ViewPageComponent ,
    ContenttwoComponent, DatasetPageComponent, LandingComponent ,
    ContentthreeComponent, TemplatePageComponent , AssetPageComponent , EmailCommunicationPageComponent,
 EndComponent , CreatePageComponent , DocumentPageComponent , DocumentTemplatePageComponent , DocumentDataPageComponent , DocumentGeneratePageComponent, PlaceholderPageComponent  ],
  imports: [
    CommonModule,
    CKEditorModule,
    FormsModule ,
    NgxDatatableModule 
  ],
  providers: [PlaceholderService]

})
export class HomePageModule { }
